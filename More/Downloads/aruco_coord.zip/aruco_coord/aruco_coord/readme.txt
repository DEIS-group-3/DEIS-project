aruco_coord have 2 nodes: 
1) publish_aruco (corresponding file is coord_publisher.py) 
It open videostream, takes a picture every 0.5 s (at least no earlier:)), find if there are aruco markers with id in moving_id=[25,42] #moving objects since we do not want to waste time on defining coordinates of static aruco markers. From that markers it takes separately coorsinates of our_id=25 and publishes it to the topic '/aruco_gps_3'
2) our_coord_aruco (corresponding file is smartphone.py)
It listenes for the topic '/aruco_gps_3'. Once smth is published in this topic, it takes the message (coordinates of our robot), define in what part of map we are (coded by numbers N={1, 2, 120, 121, 121, 340, 341, 560, 561}) and publish this code to the topic '/where_3' in the format:
x, y, code, d
where x,y - coordinates of our robot (the same that it received from publish_aruco), code of the part of the map (see above), d=distance to the closest line on the intersection. d is dependable on code (if code fails by some reason, the d will be unreasonable number)

