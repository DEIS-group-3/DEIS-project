##!/usr/bin/env python3

import re
import numpy as np

our_robot_id=4


class MessageTransformer(object):
    
    def splitter_actions(self,msg):
#         pattern = re.compile(r";|,|[|] ")
#         delimiters = ",", " ", "[", "]"
        our_id=3;
        split_string = str(msg).split(',')
        our_coord=split_string[our_id-1];
        #print(action_id)
        robot_id=split_string[1];
        #print(robot_id)
        return action_id, robot_id
    
    def splitter_robot(self,msg):
         a=[];
         
#          print((str(msg)))
#          (str(msg)).split(';')#now we have 10 messages for every robot_id
#          pattern = re.compile(r";|,|[|] ")
 #         delimiters = ",", " ", "[", "]"
         msg=re.sub('\[ |\]|\[', '', str(msg))
         #print(msg)
         x = msg.split(',')
   
         coordinates=np.array((x[0],x[1]))
         a.append((x[0],x[1]))
             
         return a
    

def main():

     print("Starting..")  
     q=MessageTransformer()
     #t=q.splitter_actions('k, 4')
     #print(t[1])
     s=['-1 -1 -1 -1 -1;-1 -1 -1 -1 -1;550.89396418456 1111.49193236916 1.53974843013584 2 0.554857314971339;442.023307909461 1114.00050625987 2.18427907071948 3 0.566817960934568;-1 -1 -1 -1 -1;-1 -1 -1 -1 -1;-1 -1 -1 -1 -1;299.524247756989 95.9661582671803 -1.55186518441895 7 0.517454436231951;-1 -1 -1 -1 -1;-1 -1 -1 -1 -1']
     print(q.splitter_robot(s))

if __name__ == '__main__':
     main()
