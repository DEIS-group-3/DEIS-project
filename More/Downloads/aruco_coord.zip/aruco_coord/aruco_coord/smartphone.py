
import rclpy #ros2 library for python
from rclpy.node import Node
from datetime import datetime
from std_msgs.msg import String
from .Map_location import LocationMap
from .Action_message_convert import MessageTransformer
import numpy as np



class SmartPhone(Node):
    flag=0

    def __init__(self):
       super().__init__("positions_listener")#name of the node
       
       self.subscriber_=self.create_subscription(String, "/aruco_gps_3", self.gps_received, 10)#robot_news is the name of the topic; 10 is buffer, max numner of msg that will be kept if they not delivered in time
       
       self.get_logger().info("Position_listener node has been created")#+ str(self.counter_)
       # Create publisher(s)   
       self.publish_to_feedback = self.create_publisher(String, '/where_3', 10)
       #self.performaction=ActionPerformer()
       
    def callback_robot_news(self,msg):
       dt_string = String();
       dt_string = datetime.now().strftime("%d/%m/%Y-%H:%M:%S.%f")
       self.get_logger().info(msg.data+ str(dt_string))   
       
    def gps_received(self, msg):
       """Callback function. This function gets called as soon as the position of the object is received."""
       m=MessageTransformer()
       try:
             our_coord = m.splitter_robot(msg.data)
       except: pass
       l=LocationMap()
      

       try:
            print(len(our_coord))
            our_coord=[(float) (our_coord[0][1]), (float)(our_coord[0][0])]
            #our_coord.reshape(1,2)
            #print(our_coord)
            w=l.where(our_coord)
            d=l.closest_line(our_coord)            #distance to the closest line
            self.publish_feedback(str(our_coord)+' '+str(w)+' '+str(d))
       except: pass
            

    
    def publish_feedback(self,my_info):

       msg = String() # Create a message of this type 
       msg.data = my_info # Store the object's position
       self.publish_to_feedback.publish(msg) # Publish the position to the topic   
       
    
def main(args=None):
    rclpy.init(args=args) #needs to be in every ros2 file. Initialize ros2 communication
    node=SmartPhone()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()#turn off ros2 communication
    
if __name__=="__main__":
     main()
