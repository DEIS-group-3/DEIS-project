#!/usr/bin/env python
# coding: utf-8

# In[7]:


import time
#from tkinter import*
#import keyboard
from cv2 import aruco
import PIL
#import pandas as pd
import cv2
import numpy as np
import logging
import os
from filterpy.kalman import KalmanFilter
import matplotlib.pyplot as plt

# import book_plots as bp



samples_max=1




aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_100)
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 960
moving_id=[25,42] #moving objects
our_id=25

class GetVideo(object):

   def kalf_in(self,coord):
  
       x_size =4 # n.o.elementsinstatevector
       z_size =2 # n.odimensionsinstatevector
       dt=0.5
       f = KalmanFilter(dim_x=x_size,dim_z=z_size) # Yawfilter
        # Uncertaintyfactor
       unc_f =4
    # DefineKalmanfilterstateestimatevector
       f.x=np.zeros((x_size,1),dtype='float') #initial state
       f.x[0][0]=coord[0][0]
       f.x[2][0]=coord[0][1]
#     print((f.x).shape)
#     f.x=np.array([[coord[0][0], 0, coord[0][1],  0]])
#     print(type(f.x))
    # statetransitionmatrix
       f.F=(np.eye(x_size))
       for j in range(0,x_size,2):
           f.F[j,j+1]=dt
#         f.F=np.array([[1, dt, 0,  0],
#                       [0,  1, 0,  0],
#                       [0,  0, 1, dt],
#                       [0,  0, 0,  1]])
        
     #  print(f.F)
#     # Measurementfunction
       f.H=np.zeros((z_size,x_size),dtype='float')
#     print((f.H).shape)
#     # Defineelementstowhichweperformcalculations
       for j in range(0,z_size):
               f.H[j,2*j]=1.0
      # print(f.H)
       f.P = np.eye(4) * 100.
       # stateuncertainty
       f.R *= unc_f
       # processnoise
       f.Q *= unc_f *0.1
         # Movingaveragefilter
       xs=[]
       ys=[]
       return f

   def kalf(self,x,y, f):
       
       tx=np.array([x,y])
#        print(type(tx))              
         # performkalmanfiltering
       if tx is not None:
               f.update(tx)
               f.predict()
       else :
               f.update(None)
               f.predict()
#        print(f.x)
       return f
   
   def detectMarkers(self,frame):
       a=[]
       a_our=[]
   
       logging.debug('detecting ArUco...')
       gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)    
       parameters =  aruco.DetectorParameters_create()
       corners, ids, rejectedImgPoints = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)
       frame_markers = aruco.drawDetectedMarkers(frame, corners, ids)
       
    #Kalman inicialization
    
       if ids is not None:
           for i in range(len(ids)):
               if ids[i] in moving_id:
                   c = corners[i][0]
                   a_new=[ids[i], c[:, 0].mean(), c[:, 1].mean()]
               #print(a_new.shape)
                   a.append(a_new)
                   if ids[i]==our_id:
                         a_our.append([c[:, 0].mean(), c[:, 1].mean()])
                    
            #print(a.shape)
            #cv2.drawMarker(frame, (c[:, 0].mean(), c[:, 1].mean()), (0,255,255), markerType=cv2.MARKER_STAR, markerSize=5, thickness=2, line_type=cv2.LINE_AA)  
    #print(a)       
       return frame, a, a_our

 
   def save_coordinates(self,an_array, txt_file):
      a_file = open(txt_file, "w")
      for row in an_array:
           np.savetxt(a_file, row, fmt='%1.3f')
   
      a_file.close()


   def test_livevideo(self,video_file=0):
       print(video_file)
       cap = cv2.VideoCapture(video_file)
    
#    cap.set(3, __SCREEN_WIDTH)
#    cap.set(4, __SCREEN_HEIGHT)
       d=[]
       fps=20
   
 #keep the same rate as initial video
       if video_file=='http://192.168.1.2//axis-cgi/mjpg/video.cgi':
          video_file="overhead_camera"
   
    # skip first second of video.
       for i in range(3):
           ret, frame = cap.read()
        #print(ret)
       coordinates=[]
       our_coordinates=[]
       Fx=[]

       try:
           j = 0
           while cap.isOpened():
               start_time = time.time()
               ret, frame = cap.read()
               #frame=cv2.resize(frame,( __SCREEN_WIDTH,__SCREEN_HEIGHT))
               if ret:
#                   print('frame %s' % j )
                  combo_image, a, our_a = self.detectMarkers(frame)
                  #print(a)
               
                  if not len(a) ==0:
   
                       coordinates.append(a)
                       print(coordinates)
                  if not len(our_a)==0:
                       our_coordinates.append(our_a)
                       if len(our_coordinates)==1:
                            F=self.kalf_in(our_a)
                            xs=[]
                            ys=[]
                         
                       else: 
                            if our_a is not None:
                                xs=np.append(xs,our_a[0][0])
                                ys=np.append(ys,our_a[0][1])
               
                                coord_x =np.average(xs)
                                coord_y =np.average(ys)
                                if np.size(xs) >= samples_max:
                    
                                        xs=np.delete(xs,0)
                                        ys=np.delete(ys,0) 
#                           print([coord_x,coord_y])
                                F=self.kalf(coord_x, coord_y,F)
                                Fx.append((F.x).transpose().tolist())
#                           print(Fx)
                    
               combo_image=cv2.resize(combo_image,(SCREEN_WIDTH,SCREEN_HEIGHT))     
               
               cv2.imshow("Frame with ArUco", combo_image)
               j += 1
               rt=0.5 - time.time() + start_time
               if rt>0:
                    time.sleep(rt)
               if cv2.waitKey(1) & 0xFF == ord('q'):
                       break
       finally:
           cap.release()
           video_overlay.release()
           cv2.destroyAllWindows()
           print("Writing coordinates to the file..")
           #print(type(coordinates))
           #print(type(our_coordinates))
           self.save_coordinates(coordinates, "coordinates_live1.txt")
           #if not len(coordinates):
             #    print(len(coordinates))
                 
           try:
                  self.save_coordinates(our_coordinates, "our_coordinates_live.txt")
           except: 
                 print("Can't write in the file")
           try:
                  self.save_coordinates(Fx,"kalman_live.txt")
           except: 
                 print("Can't write in the file")
   
   


   def test_photo(self,file): #for testing photo  
#        retval  =   cv2.haveImageReader (file)
       a_our=[]
       try:
    #ignore if no such file is present.
            frame, a, a_our = cv2.imread(file) 
            combo_image = detectMarkers(frame)
            cv2.imshow('final', combo_image)
         
            cv2.waitKey(0)
            cv2.destroyAllWindows()
       except:
            print("Can't connect")
       if not len(a_our)==0:
          return a_our
       else: return None
        
#     if not retval:
# #         break      
#          print("File not found")
#          print("Finishing..")
#          return 0
#     else:
#         return frame

   def head_photo(self): #for testing photo  
   
       frame = cv2.imread('http://192.168.1.2//axis-cgi/mjpg/video.cgi') 
       combo_image = self.detectMarkers(frame)
       cv2.imshow('final', combo_image)
         
       cv2.waitKey(0)
       cv2.destroyAllWindows()
    

   def plot_output(self, file_measurements, file_kalman, title=None, aspect_equal=True):
#     with open(file_measurements, 'r') as g1:
#          my_meas = [line.strip() for line in g1 if line]
#     with open(file_kalman, 'r') as g2:
#          my_kalm = [line.strip() for line in g2 if line]
       my_meas=np.loadtxt(file_measurements)
       my_kalm=np.loadtxt(file_kalman)
#     g1 = open(file_measurements, 'r+')
#     my_meas = g1.read()
#     g1.close()
    
       N=min(len(my_meas), len(my_kalm))
       print()
    
#     if (len((my_meas))<len(my_kalm)):
#         remove_last_element(my_kalm)
#     elif (len((my_meas))>len(my_kalm)):
#         remove_last_element(my_meas)
        
       t=np.linspace(0,dt*N,num=N).transpose()
       my_meas=np.array(my_meas)
       #print(t.shape)
       #print(my_meas.shape)
       #print(my_kalm.shape)
       plt.figure()
       plt.plot(t,my_meas[:-1,0],'x')
       plt.plot(t,my_kalm[:,0])
       plt.grid()
       plt.show()
    
       plt.figure()
       plt.plot(t,my_meas[:-1,1],'x')
       plt.plot(t,my_kalm[:,2])
       plt.grid()
       plt.show()

    

def main():

       wrk_dir=os.path.abspath(os.getcwd())
       print(wrk_dir)
    #wrk_dir="C:\Users\galsid\Documents\Phd course\Robots\Aruco"
       print(wrk_dir)
#    test_video()
       qk=GetVideo()
       #qk.test_livevideo('http://192.168.1.2//axis-cgi/mjpg/video.cgi')
       qk.test_photo('http://192.168.1.2/axis-cgi/jpg/image.cgi')
    #test_video(wrk_dir + "\Video\head_cam_3.avi")
       if not os.stat("kalman_live.txt").st_size==0:
            plot_output("our_coordinates_live.txt","kalman_live.txt")
    #test_photo(wrk_dir+q'\pictures\image_40.png') 

if __name__ == '__main__':
     main()

 



