// file: send_message.c
//
// LCM example program.
//
// compile with:
//  $ gcc -o send_message send_message.c -llcm
//
// On a system with pkg-config, you can also use:
//  $ gcc -o send_message send_message.c `pkg-config --cflags --libs lcm`

#include <lcm/lcm.h>
#include "exlcm_example_t.h"
#include <time.h>
#include <stdio.h>
#include <inttypes.h>


void waitFor (unsigned int secs) {
    unsigned int retTime = time(0) + secs;   // Get finishing time.
    while (time(0) < retTime);               // Loop until it arrives.
}

int
main(int argc, char ** argv)
{
 
    
    for (; ; ) {   
    
       lcm_t * lcm = lcm_create(NULL);
    if(!lcm)
        return 1; 
    exlcm_example_t my_data = {
        .timestamp = (unsigned long)time(NULL), //time now
        .position = { 1, 2, 3 },
        .orientation = { 1, 0, 0, 0 },
    };
    int16_t ranges[15];
    int i;
    for(i = 0; i < 15; i++)
        ranges[i] = i;
    my_data.num_ranges = 15;
    my_data.ranges = ranges;
    my_data.name = "heartbeat";
    my_data.enabled = 1;
    exlcm_example_t_publish(lcm, "HEARTBEAT", &my_data);
    printf("  timestamp   = %" PRId64 "\n", my_data.timestamp);
    lcm_destroy(lcm);
    waitFor(1);
    }
    return 0;
}
