#!/bin/bash

#declare --
#N=3;

#./listener
#if [ $exit_status -eq 127 ]; then
#    echo 'no'
#fi

trap "exit" INT TERM ERR
trap "kill 0" EXIT

for i in {1..3}
do
	./send_heartbeat $i &
if [ $exit_status -eq 127 ]; then
    echo 'no'
fi
done 

wait
