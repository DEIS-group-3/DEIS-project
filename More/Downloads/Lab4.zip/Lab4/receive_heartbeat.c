// file: listener.c
//
// LCM example program.
//
// compile with:
//  $ gcc -o listener listener.c -llcm
//
// On a system with pkg-config, you can also use:
//  $ gcc -o listener listener.c `pkg-config --cflags --libs lcm`

#include <inttypes.h>
#include <lcm/lcm.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include "exlcm_example_t.h"

unsigned long receive_pkts = 0;

static void my_handler(const lcm_recv_buf_t *rbuf, const char *channel, const exlcm_example_t *msg,
                       void *user)
{
    int i;
    	struct timespec now;
    //printf("Received time  = %" PRId64 "\n", (unsigned long)clock());//Redundent
    clock_gettime(CLOCK_REALTIME, &now);
    //printf("Sender ID:%d\n", msg->ID);
    //printf("message on channel \"%s\":\n", channel);
    printf("%d:%ld\n", msg->ID, (int64_t)now.tv_nsec);
    printf("%d:%ld\n", msg->ID, msg->timestamp);
    printf("%d:%ld\n", msg->ID, ((int64_t)now.tv_nsec - msg->timestamp));
    printf("%d:%f\n", msg->ID, ((int64_t)now.tv_nsec - msg->timestamp)/(double)(CLOCKS_PER_SEC));
    
    //printf("timestamp from sender  = %" PRId64 "\n", rec - msg->timestamp);
    //printf("  position    = (%f, %f, %f)\n", msg->position[0], msg->position[1], msg->position[2]);
    //printf("  orientation = (%f, %f, %f, %f)\n", msg->orientation[0], msg->orientation[1],
    //       msg->orientation[2], msg->orientation[3]);
    //printf("  ranges:");
    //for (i = 0; i < msg->num_ranges; i++)
    //    printf(" %d", msg->ranges[i]);
    //printf("\n");
    //printf("  name        = '%s'\n", msg->name);
    //printf("  enabled     = %d\n", msg->enabled);
    receive_pkts++;
}

int main(int argc, char **argv)
{
    
    lcm_t *lcm = lcm_create(NULL);
    if (!lcm)
        return 1;

    exlcm_example_t_subscribe(lcm, "HEARTBEAT", &my_handler, NULL);

    while (receive_pkts < 1000)
        lcm_handle(lcm);

    lcm_destroy(lcm);
    return 0;
}
